# Flutter Todo App

A simple Flutter Todo app for portfolio use.

## Features
- Add tasks
- Mark tasks as completed
- Delete tasks (swipe or button)
- Clear all tasks

## Run the project
```
flutter run
```
